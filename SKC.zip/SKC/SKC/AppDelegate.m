//
//  AppDelegate.m
//  SKC
//
//  Created by apple on 2019/6/21.
//  Copyright © 2019 Henry. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@property (weak) IBOutlet NSWindow *window;

@end

enum resultType{
    A = 0,
    B = 1,
    C = 2,
    D = 3
};

@implementation AppDelegate

- (instancetype)init
{
    self = [super init];
    if (self) {
//        options = [[NSMutableArray alloc]initWithObjects:OptionA,OptionB,OptionC,OptionD, nil];//无效
        answerStr = [[NSMutableArray alloc]initWithObjects:@"A",@"B",@"C",@"D", nil];
        questions = [[NSMutableArray alloc]init];
        [self loadQuestionFile:@"question1.txt"];//无法一次性读取完整文件内容，故分文两个文件
        [self loadQuestionFile:@"question2.txt"];
    }
    return self;
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    rightImage = [[NSImageView alloc]init];
    rightImage.image = [NSImage imageNamed:@"Right"];
    rightImage.frame = NSMakeRect(0, 0, 80, 60);
    [rightImage setImageScaling:NSImageScaleAxesIndependently];
    errorImage = [[NSImageView alloc]init];
    errorImage.image = [NSImage imageNamed:@"Error"];
    errorImage.frame = NSMakeRect(0, 0, 80, 60);
    [errorImage setImageScaling:NSImageScaleAxesIndependently];
    
    answerProgress.indeterminate = NO;
    answerProgress.minValue = 0;
    answerProgress.maxValue = questions.count;
    
    currentIndex = 0;
    questionCount = questions.count;
    [self UIRefresh];
    [self drawResult:@"" withImage:nil];
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender{
    return YES;
}

- (void)UIRefresh{
    Question *q = questions[currentIndex];
    TestItem.stringValue = [q getQuestion];
    optionAText.stringValue = [q getOptions][A];
    optionBText.stringValue = [q getOptions][B];
    optionCText.stringValue = [q getOptions][C];
    optionDText.stringValue = [q getOptions][D];
    
    
    [OptionA setState:NSOffState];//Radio按钮默认同一个父视图下只选择一个，通过将其存入列表统一初始化无效，故逐个初始化
    [OptionB setState:NSOffState];
    [OptionC setState:NSOffState];
    [OptionD setState:NSOffState];
    
    [answerProgress setDoubleValue:currentIndex];
}

- (void)loadQuestionFile:(NSString *)filename{
    NSString *path = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:filename];
    if([[NSFileManager alloc]fileExistsAtPath:path]){
        NSString *filecontent = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
        NSArray *fileArr = [filecontent componentsSeparatedByString:@"\n"];
        
        [self initQuestion:fileArr];
        
//        for(NSString *str in fileArr){
//            NSLog(@"%@",str);
//        }
//        NSLog(@"%@",filecontent);
    }
}

- (void)initQuestion:(NSArray *) arr{
    NSMutableArray *tempArr = [[NSMutableArray alloc]init];
    NSInteger count = 0;
    for(NSString *str in arr){
        if(count >= 5){
            NSMutableArray *optionsArr = [[NSMutableArray alloc]initWithObjects:tempArr[1],tempArr[2],tempArr[3],tempArr[4], nil];
            NSString *answer = [[tempArr[0] stringByMatching:@"\\(\\s*\\w\\s*\\)"]stringByMatching:@"\\w"];
            NSString *questionPart1 = [[tempArr[0] stringByMatching:@".+\\(\\s*\\w"]stringByMatching:@".+\\("];
            NSString *questionPart2 = [[tempArr[0] stringByMatching:@"\\w\\s*\\).*"]stringByMatching:@"\\).*"];
            NSMutableString *question = [[NSMutableString alloc]initWithFormat:@"%@ %@",questionPart1,questionPart2];
//            NSLog(@"%@",tempArr[0]);
//            NSLog(@"%@",answer);
//            NSLog(@"%@",question);
//            NSLog(@"%@",tempArr[1]);
//            NSLog(@"%@",tempArr[2]);
//            NSLog(@"%@",tempArr[3]);
//            NSLog(@"%@",tempArr[4]);
            Question *q = [[Question alloc]initWithQuestionStr:question withAnswerStr:answer withOption:optionsArr];
            [questions addObject:q];
            [tempArr removeAllObjects];
            count=0;
        }
        if(str && [str isNotEqualTo:@""]){
            [tempArr addObject:str];
            count = count + 1;
        }
    }
    
}

- (IBAction)SelectOption:(id)sender {
    NSButton *select = sender;
    myselect = answerStr[select.tag];
    Question *q = questions[currentIndex];
    if([q answerQuestion:myselect]){
        [self drawResult:@"" withImage:rightImage];
    }else{
        NSMutableString *str = [[NSMutableString alloc]initWithString:@"正确答案:"];
        [str appendString:[q getAnswer]];
        [self drawResult:str withImage:errorImage];
    }
}

- (IBAction)prevQuestion:(id)sender {
    if(currentIndex <= 0){
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"确认"];//增加一个按钮
        [alert setMessageText:@"警告"];//提示的标题
        [alert setInformativeText:@"已经是第一题！！！"];//提示的详细内容
        [alert setAlertStyle:NSAlertStyleInformational];//设置警告⻛格
        [alert beginSheetModalForWindow:self.window
                      completionHandler:^(NSModalResponse returnCode){
                          //用户点击警告上面的按钮后的回调
                      }];
    }else{
        currentIndex = currentIndex - 1;
        [self UIRefresh];
        [self drawResult:@"" withImage:nil];
    }
}

- (IBAction)nextQuestion:(id)sender {
    if(currentIndex >= questionCount-1){
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"确认"];//增加一个按钮
        [alert setMessageText:@"警告"];//提示的标题
        [alert setInformativeText:@"已经是最后一题！！！"];//提示的详细内容
        [alert setAlertStyle:NSAlertStyleInformational];//设置警告⻛格
        [alert beginSheetModalForWindow:self.window
                      completionHandler:^(NSModalResponse returnCode){
                          //用户点击警告上面的按钮后的回调
                      }];
    }else{
        currentIndex = currentIndex + 1;
        [self UIRefresh];
        [self drawResult:@"" withImage:nil];
    }
}


- (void)drawResult:(NSString *) resultStr withImage:(NSImageView *) image
{
    if(resultView.subviews.count > 0){
        [resultView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    }
    [resultView addSubview:image];
    Result.stringValue = resultStr;
}

@end
