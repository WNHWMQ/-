//
//  Question.m
//  SKC
//
//  Created by apple on 2019/6/22.
//  Copyright © 2019 Henry. All rights reserved.
//

#import "Question.h"

@implementation Question

- (instancetype)init
{
    self = [super init];
    if (self) {
        questionStr = @"";
        answerStr = @"";
        options = [[NSMutableArray alloc]init];
    }
    return self;
}

- (Question *)initWithQuestionStr:(NSString *) qs withAnswerStr:(NSString *) as withOption:(NSMutableArray *) option{
    questionStr = qs;
    answerStr = as;
    options = [[NSMutableArray alloc]initWithArray:option];
    return self;
}

-(BOOL)answerQuestion:(NSString *)answer{
    if([answer isEqualToString:answerStr]){
        return YES;
    }else{
        return NO;
    }
}

-(NSString *)getAnswer{
    return answerStr;
}

-(NSString *)getQuestion{
    return questionStr;
}

-(NSMutableArray *)getOptions{
    return options;
}

@end
