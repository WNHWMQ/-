//
//  AppDelegate.h
//  SKC
//
//  Created by apple on 2019/6/21.
//  Copyright © 2019 Henry. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Question.h"
#import "RegexKitLite.h"

@interface AppDelegate : NSObject <NSApplicationDelegate>
{
    IBOutlet NSTextField *TestItem;
    IBOutlet NSButton *OptionA;
    IBOutlet NSButton *OptionB;
    IBOutlet NSButton *OptionC;
    IBOutlet NSButton *OptionD;
    IBOutlet NSButton *prev;
    IBOutlet NSButton *next;
    IBOutlet NSView *resultView;
    IBOutlet NSProgressIndicator *answerProgress;
    IBOutlet NSTextField *Result;
    IBOutlet NSTextField *optionAText;
    IBOutlet NSTextField *optionBText;
    IBOutlet NSTextField *optionCText;
    IBOutlet NSTextField *optionDText;
    
    
    NSString *myselect;
    NSMutableArray *options;
    NSMutableArray *questions;
    NSMutableArray *answerStr;
    NSImageView *rightImage;
    NSImageView *errorImage;
    NSInteger currentIndex;
    NSInteger questionCount;
    
}
- (void)drawResult:(NSString *) resultStr withImage:(NSImageView *) image;
- (void)initQuestion:(NSArray *)arr;
- (void)loadQuestionFile:(NSString *)filename;
- (void)UIRefresh;

@end

