//
//  main.m
//  SKC
//
//  Created by apple on 2019/6/21.
//  Copyright © 2019 Henry. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
