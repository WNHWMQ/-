//
//  Question.h
//  SKC
//
//  Created by apple on 2019/6/22.
//  Copyright © 2019 Henry. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Question : NSObject{
    NSString *questionStr;
    NSString *answerStr;
    NSMutableArray *options;
}
- (Question *)initWithQuestionStr:(NSString *) qs withAnswerStr:(NSString *) as withOption:(NSMutableArray *) option;
-(BOOL)answerQuestion:(NSString *) answer;
-(NSString *)getAnswer;
-(NSString *)getQuestion;
-(NSMutableArray *)getOptions;

@end
